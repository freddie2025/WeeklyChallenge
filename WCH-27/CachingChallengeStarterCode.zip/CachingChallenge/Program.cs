﻿using System;
using System.Linq;

namespace CachingChallenge
{
    class Program
    {
        static void Main(string[] args)
        {
            
            Console.ReadLine();
        }
    }
}
